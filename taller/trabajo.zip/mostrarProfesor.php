<?php
	include_once ("ColectorProfesor.php");

	 $id=1;

	 $ColectorProfesor = new ColectorProfesor();

	 foreach ($ColectorProfesor->mostrarProfesores() as $c) {
	 	echo "<div>";
	 	echo $c->getIdProfesor() . " && " .$c->getNombre();
	 	echo "</div>";
	 }

?>
