<?php

include('databaseControlador.php');
include('Profesor.php');

class ColectorProfesor extends databaseControlador
{
    
    function mostrarProfesores() {
    $rows = self::$db->getRows("SELECT * FROM Profesor");        
    $arrayProfesores= array();
    
        foreach ($rows as $c){
          $ProfesoresAux = new Club($c{'idProfesor'},$c{'nombre'},$c{'apellido'},$c{'email'});
          array_push($arrayProfesores, $ProfesoresAux);
        }
    return $arrayProfesores;        
  }

}
?>
